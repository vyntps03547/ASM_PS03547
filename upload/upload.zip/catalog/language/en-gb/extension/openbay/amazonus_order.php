<?php
// Text
$_['text_paid_amazon'] 			= 'Paid on Amazon US';
$_['text_total_shipping'] 		= 'Shipping';
$_['text_total_shipping_tax'] 	= 'Shipping tax';
$_['text_total_giftwrap'] 		= 'Gift wrap';
$_['text_total_giftwrap_tax'] 	= 'Gift wrap tax';
$_['text_total_sub'] 			= 'Sub-total';
$_['text_tax'] 					= 'Tax';
$_['text_total'] 				= 'Total';