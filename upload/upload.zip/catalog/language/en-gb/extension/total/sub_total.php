<?php
$_['text_sub_total'] = 'Sub-Total';